window.__CONFIG__ = {
  // url must NOT end with a slash
  VITE_CORS_PROXY_URL: "",
  VITE_TMDB_READ_API_KEY: ""
};
