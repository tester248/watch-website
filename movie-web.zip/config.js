window.__CONFIG__ = {
  // url must NOT end with a slash
  VITE_CORS_PROXY_URL: "",
  VITE_TMDB_API_KEY: "b030404650f279792a8d3287232358e3",
  VITE_OMDB_API_KEY: "aa0937c0",
};
